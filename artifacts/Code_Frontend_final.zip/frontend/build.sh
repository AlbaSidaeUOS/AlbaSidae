#!/bin/sh
cd ../
mkdir output
cp -R ./AlbaSidae-FE/* ./output
cp -R ./output ./AlbaSidae-FE/
