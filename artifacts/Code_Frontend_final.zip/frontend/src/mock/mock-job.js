// 알바 공고 목업 데이터

const MOCK_JOBLIST = [
  { company: "A회사", title: "판매사원 모집", location: "전국, 공고별 확인" },
  { company: "B회사", title: "판매사원 모집", location: "전국, 공고별 확인" },
  { company: "C회사", title: "판매사원 모집", location: "전국, 공고별 확인" },
  { company: "D회사", title: "판매사원 모집", location: "전국, 공고별 확인" },
  { company: "E회사", title: "판매사원 모집", location: "전국, 공고별 확인" },
  { company: "F회사", title: "판매사원 모집", location: "전국, 공고별 확인" },
  { company: "G회사", title: "판매사원 모집", location: "전국, 공고별 확인" },
  { company: "H회사", title: "판매사원 모집", location: "전국, 공고별 확인" },
  { company: "I회사", title: "판매사원 모집", location: "전국, 공고별 확인" },
  { company: "J회사", title: "판매사원 모집", location: "전국, 공고별 확인" },
  { company: "K회사", title: "판매사원 모집", location: "전국, 공고별 확인" },
  { company: "L회사", title: "판매사원 모집", location: "전국, 공고별 확인" },
];

export default MOCK_JOBLIST;
