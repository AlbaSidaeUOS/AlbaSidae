package albabe.albabe.domain.enums;

/*
    Description : 회원 종류를 담고 있는 enum 자료형 선언 소스파일
 */

public enum UserRole {
    PERSONAL, COMPANY, ADMIN;
}
